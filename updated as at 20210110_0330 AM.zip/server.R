#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(shiny)
library(leaflet)
library(dplyr)

#Folder<-"C:\\Users\\MollynTeh\\Desktop\\WQD7001 Principle of Data Science\\Group Project\\ShinyApp\\JapanHostel\\"
dat_hostel<-read.csv(file = "Hostel.csv",stringsAsFactors = F)
dat_hostel<-dat_hostel[-c(1,8,17)]
dat_hostel<-dat_hostel[apply(dat_hostel,1,function(X) !any(is.na(X))),]
dat_hostel <- dat_hostel %>% rename(
    "HostelName" = hostel.name,
    "StartingPrice" = price.from,
    "RatingBand" = rating.band,
    "RatingScore" = summary.score,
    "Cleanliness" = cleanliness,
    "Facilities" = facilities,
    "Location" = location.y,
    "Security" = security,
    "Staff" = staff,
    "ValueForMoney" = valueformoney
)

cityChoices <- c(unique(dat_hostel$City))


server<-shinyServer(function(input,output,session){
####MAP####  
    dat_temp<-reactive({
        if (input$city=="All"){
            dat_hostel
        }else{
            filter(dat_hostel,City==input$city)
        }})

    
    dat_temp2<-reactive({filter(dat_temp()
                                ,RatingScore<=input$RS[2]
                                ,RatingScore>input$RS[1])})
    
    dat_temp3<-reactive({filter(dat_temp2()
                                ,Cleanliness<=input$CL[2]
                                ,Cleanliness>input$CL[1])})
    
    dat_temp4<-reactive({filter(dat_temp3()
                                ,Cleanliness<=input$SE[2]
                                ,Cleanliness>input$SE[1])})
    
    
    
    #dat_temp2<-reactive({select(dat_temp(),-lon:lat)})
    output$out<-renderTable(reactive({select(dat_temp4(),-lon,-lat,-Distance)})())
    output$mymap<-renderLeaflet(
        addAwesomeMarkers(addTiles(leaflet())
                          ,lng=dat_temp4()$lon
                          ,lat=dat_temp4()$lat)
    )
}
)

