library(shiny)
library(leaflet)
library(dplyr)
library(ggplot2)

cityChoices <- c(unique(dat_hostel$City))

ui <- shinyUI(fluidPage(
    wellPanel(
        tags$style(".well {background-color:#EBFBFF;}"),
        
        fluidRow(
            column(
                width = 12,
                titlePanel("Japan Hostel"),
                tabsetPanel(
                    tabPanel("Home-Introduction",
                             h3("Introduction"),
                             p("write our intro here"),
                             br(),
                             h3("Objectives"),
                             p("1. To find hostels at a cheaper price saves money."),
                             p("2. To create a data app with no ads saves time."),
                             p("3. To provide location-based hostel searching in Japan."),
                             br(),
                             h3("Interesting Question"),
                             p("1. Which hostel has the best rating in the city?"),
                             p("2. Which hostel is nearer to city?"),
                             p("3. How other attributes influence hostel prices?"),),
                    tabPanel("Find Your Hostel",
                             br(),
                             leafletOutput("mymap"),
                             fluidRow(verbatimTextOutput("map_marker_click")),
                             br(),
                             sidebarLayout(
                                 sidebarPanel(
                                     selectInput("city","City : ", c("All",unique(dat_hostel$City))),
                                     sliderInput("RS","Rating Score :"
                                                 ,min=1,max=10,value = c(1,10),step=0.1),
                                     sliderInput("CL","Cleanliness :"
                                                 ,min=1,max=10,value = c(1,10),step=0.1),
                                     sliderInput("SE","Security :"
                                                 ,min=1,max=10,value = c(1,10),step=0.1)
                                                                      )
                                 ,mainPanel(
                                     tableOutput("out")))),
                    tabPanel("Insights",
                             h3("Graphs & Charts here"),
                    ),
                    tabPanel("About this App",
                             h3("Goreng something here..."))
                ))))))
